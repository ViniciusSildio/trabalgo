package com.example.trabalholoja.dominio;

import jdk.jfr.Enabled;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.Date;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "produto")
public class Produto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(length = 100,nullable = false)
    @NotNull(message = "nome do produto não pode ser nulo")

    private String nome;
    @Column(nullable = false)
    @NotNull(message = "preço do produto não pode ser nulo")

    private Double preco;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "Data_De_Registro" )
    private Date Data_De_Registro;
}
