package com.example.trabalholoja.exesoes;

public class ObigetoNaoEncontrado extends RuntimeException {

    public ObigetoNaoEncontrado(String msg){
        super (msg);
    }
    public ObigetoNaoEncontrado(String msg, Throwable cause){
        super(msg,cause);
    }

}
