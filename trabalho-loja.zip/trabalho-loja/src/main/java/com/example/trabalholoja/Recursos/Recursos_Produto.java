package com.example.trabalholoja.Recursos;

import com.example.trabalholoja.dominio.Produto;
import com.example.trabalholoja.serviso.ServisoDeProduto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping(value = "produtos")
public class Recursos_Produto {
    @Autowired
   private ServisoDeProduto servisoDeProduto;


    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<Void> save(@Valid @RequestBody Produto produto){
        servisoDeProduto.save(produto);
    return ResponseEntity.noContent().build();
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<Produto>> findAll(){
        return ResponseEntity.ok().body(servisoDeProduto.findAll());
    }

    @RequestMapping(method = RequestMethod.GET, value = "{id}")
    public ResponseEntity<Produto> findById(@PathVariable Long id){
        return ResponseEntity.ok().body(servisoDeProduto.findById(id));
    }

    @RequestMapping(method = RequestMethod.GET,value = "nome/{nome}")
    public ResponseEntity<List<Produto>> findAll(@PathVariable String nome){
        return ResponseEntity.ok().body(servisoDeProduto.findAllByNome(nome));
    }


}
