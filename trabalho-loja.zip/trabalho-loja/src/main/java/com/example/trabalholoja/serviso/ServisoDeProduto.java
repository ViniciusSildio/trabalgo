package com.example.trabalholoja.serviso;


import com.example.trabalholoja.dominio.Produto;
import com.example.trabalholoja.exesoes.ObigetoNaoEncontrado;
import com.example.trabalholoja.repositorio.RepositorioDeProduto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.Date;
import java.util.List;

@Service
public class ServisoDeProduto {
    @Autowired
    private RepositorioDeProduto repository;

    @Autowired
    private EntityManager em;

    public void save (Produto produto){
    produto.setData_De_Registro(new Date());
    repository.save(produto);
    }
    public List<Produto> findAll(){
        return repository.findAll();
    }

    public Produto findById(Long id){
        return repository.findById(id).orElseThrow( ()-> new ObigetoNaoEncontrado("Produto não encontrado"));
    }

    public List<Produto> findAllByNome(String nome){
        return repository.findAllByNomeLike("%"+nome+"%");
    }

    public List<Produto> createCriteria(String nome){
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Produto> query = cb.createQuery(Produto.class);
        Root<Produto> pRoot = query.from(Produto.class);

        Predicate nomePredicate = cb.equal(pRoot.get("nome"), nome);
        query.where(nomePredicate);

        TypedQuery<Produto> res = em.createQuery(query);
        return res.getResultList();


    }
}
