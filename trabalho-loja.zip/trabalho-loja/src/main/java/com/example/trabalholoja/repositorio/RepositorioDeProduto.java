package com.example.trabalholoja.repositorio;

import com.example.trabalholoja.dominio.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.persistence.ExcludeSuperclassListeners;
import java.util.List;

@Repository
public interface RepositorioDeProduto extends JpaRepository<Produto,Long> {

    @Query("select from Produto e where e.nome like : nome")
    public List<Produto> findAllByNomeLike(String nome);


}
