package com.example.trabalholoja.Recursos;


import com.example.trabalholoja.dominio.StandardError;
import com.example.trabalholoja.exesoes.ObigetoNaoEncontrado;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;

@ControllerAdvice
public class RecursoDeManipulacaoDeExecao {
    @ExceptionHandler(ObigetoNaoEncontrado.class)
    public ResponseEntity<StandardError> ObigetoNaoEncontrado(ObigetoNaoEncontrado e, HttpServletRequest request
    ){
        StandardError err = new StandardError(System.currentTimeMillis(), HttpStatus.BAD_REQUEST.value(),"nao encontrado",e.getMessage(),request.getRequestURI()
        );
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(err);
    }

}
